sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/model/formatter",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, formatter, MessageToast, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.controller.TruckArrival", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.TruckArrival
		 */
		formatter: formatter,

		onInit: function () {
			var oArrivalViewModel = new JSONModel();
			this.getView().setModel(oArrivalViewModel, "arrivalViewModel");
			this._initializeData();

		},
		_initializeData: function () {
			this.oModel = this.getView().getModel();
			this.oModel.read("/ZOGS_TAC_PLANT_LST", {
				success: function (oData) {
					var formData = {
						"IsCreatingFromHO": false,
						"ArrivalDate": null,
						"TruckNumber": "",
						"DriverCode": "",
						"FullName": "",
						"Plant": "",
						"CreatedBy": "",
						"PlantTxt": "",
						"CallingFrom": "ARRIVAL",
						"ArrivalTime": null,
						"ReportedBy": "",
						"Carrier": ""
					};
					this.getView().getModel("arrivalViewModel").setData(formData);
					this.getView().getModel("arrivalViewModel").setProperty("/PlantTxt", oData.results[0].PlantTxt);
					this.getView().getModel("arrivalViewModel").setProperty("/Plant", oData.results[0].Plant);
					this.getView().byId("datepic").setDateValue(new Date());
					this.getView().byId("Timepic").setDateValue(this.formatter.getTimeOnly());
				}.bind(this),
				error: function () {

				}
			});

		},

		onTruckF4: function () {
			this.getView().setBusy(true);
			this.getView().getModel().read("/ZOGS_TAC_VEHICLE_LST", {
				success: function (oData) {
					this.getView().getModel("arrivalViewModel").setProperty("/TruckResults", oData.results);
					this.getView().setBusy(false);
					this.oTruckDialog.setBusy(false);
				}.bind(this)
			});
			if (!this.oTruckDialog) {
				this.oTruckDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.Truck", this);
				this.getView().addDependent(this.oTruckDialog);
			}
			this.oTruckDialog.setBusy(true);
			this.oTruckDialog.open();
		},

		handleTruckSearch: function (oEvent) {
			var oBinding, oFilterVehicleNo, oFilterType, oFilterCarrier, oFilterAll, sValue = oEvent.getParameter("value");
			oFilterVehicleNo = new Filter("VehicleNumber", FilterOperator.EQ, sValue);
			oFilterType = new Filter("VehicleType", FilterOperator.Contains, sValue);
			oFilterCarrier = new Filter("CarrierID", FilterOperator.EQ, sValue);
			oFilterAll = new Filter({
				filters: [oFilterVehicleNo, oFilterType, oFilterCarrier],
				and: false
			});
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterAll]);
		},

		handleTruckConfirm: function (oEvent) {
			var oBinding, oBindingContext = oEvent.getParameter("selectedItem").getBindingContext("arrivalViewModel").getObject();
			this.getView().getModel("arrivalViewModel").setProperty("/TruckNumber", oBindingContext.VehicleNumber);
			this.getView().getModel("arrivalViewModel").setProperty("/Carrier", oBindingContext.CarrierID);
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		handleTruckClose: function (oEvent) {
			var oBinding;
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		onDriverF4: function (oEvent) {
			this.getView().setBusy(true);
			this.getView().getModel().read("/ZOGS_TAC_DRIVER_LST", {
				success: function (oData) {
					this.getView().getModel("arrivalViewModel").setProperty("/results", oData.results);
					this.getView().setBusy(false);
					this.oDriverDialog.setBusy(false);
				}.bind(this)
			});
			if (!this.oDriverDialog) {
				this.oDriverDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.Driver", this);
				this.getView().addDependent(this.oDriverDialog);
			}
			this.oDriverDialog.open();
			this.oDriverDialog.setBusy(true);
		},

		handleDriverSearch: function (oEvent) {
			var oBinding, oFilterCode, oFilterName, oFilterCarrier, oFilterAll, sValue = oEvent.getParameter("value");
			oFilterCode = new Filter("DriverCode", FilterOperator.EQ, sValue);
			oFilterName = new Filter("FullName", FilterOperator.Contains, sValue);
			oFilterCarrier = new Filter("CarrierID", FilterOperator.EQ, sValue);
			oFilterAll = new Filter({
				filters: [oFilterCode, oFilterName, oFilterCarrier],
				and: false
			});
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterAll]);
		},

		handleConfirm: function (oEvent) {
			var oBindingContext = oEvent.getParameter("selectedItem").getBindingContext("arrivalViewModel").getObject();
			this.getView().getModel("arrivalViewModel").setProperty("/DriverCode", oBindingContext.DriverCode);
			this.getView().getModel("arrivalViewModel").setProperty("/FullName", oBindingContext.FullName);
		},

		handleClose: function (oEvent) {
			var oBinding;
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		_onCreate: function () {
			this.getView().setBusy(true);
			var oPayload = {},
				oDate = this.formatter.getFormatedDate(this.getView().byId("datepic").getDateValue()),
				oTime;
			oTime = this.formatter.getFormatedTime(this.getView().byId("Timepic").getDateValue());
			this.getView().getModel("arrivalViewModel").setProperty("/ArrivalDate", oDate);
			this.getView().getModel("arrivalViewModel").setProperty("/ArrivalTime", oTime);
			oPayload.CallingFrom = "ARRIVAL";
			oPayload.Trucks = [];
			oPayload.Trucks.push(this.getView().getModel("arrivalViewModel").getData());
			delete oPayload.Trucks[0].results;
			delete oPayload.Trucks[0].TruckResults;
			delete oPayload.Trucks[0].FullName;
			delete oPayload.Trucks[0].Carrier;
			this.oModel.create("/Heads", oPayload, {
				success: function (oData, oResponse) {
					MessageToast.show("Truck Details Created");
					this._initializeData();
					this.getView().setBusy(false);
				}.bind(this),
				error: function (oError) {
					var err = JSON.parse(oError.responseText).error.message.value;
					MessageToast.show(err);
					this.getView().setBusy(false);
				}.bind(this)
			});
		},

		_onReset: function () {
			this._initializeData();
			this.getView().byId("datepic").setDateValue(null);
			this.getView().byId("Timepic").setDateValue(null);
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.TruckArrival
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.TruckArrival
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.TruckArrival
		 */
		//	onExit: function() {
		//
		//	}

	});

});