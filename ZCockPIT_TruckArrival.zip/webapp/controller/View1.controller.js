sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.controller.View1", {
		onInit: function () {
			var sPath,
				oView = this.getView(),
				oUser, oViewModel = new JSONModel(),
				oViewReady;
			/*sPath = this.oModel.createKey("/Authorizations", {
				UserName: oUser
			});*/
			this.oModel = this.getView().getModel();
			this.oModel.read("/Authorizations('" + oUser + "')", {
				success: function (oData) {
					oView.getModel("viewModel").setProperty("/IsAuthorisedTruckArrival", oData.IsAuthorisedTruckArrival);
					oView.getModel("viewModel").setProperty("/IsAuthorisedTruckCall", oData.IsAuthorisedTruckCall);
					oView.getModel("viewModel").setProperty("/IsAuthorisedTruckWelcome", oData.IsAuthorisedTruckWelcome);
					oView.setBusy(false);
				}.bind(this),
				error: function (error) {
					this.getView().byId("page").setVisible(false);
					var err = JSON.parse(error.responseText).error.message.value;
					MessageBox.error(err);
					oView.setBusy(false);
				}.bind(this)
			});
			oViewReady = Promise.all([this.byId("TruckArrival").loaded(), this.byId("TruckParking").loaded(),
				this.byId("TruckWelcome").loaded()
			]);
			oViewReady.then(function (aViews) {
				this.TruckArrivalController = aViews[0].getController();
				this.TruckParkingController = aViews[1].getController();
				this.TruckWelcomeController = aViews[2].getController();
			}.bind(this));
			oView.setBusy(true);
			oView.setModel(oViewModel, "viewModel");
			oView.getModel("viewModel").setProperty("/ArrivalButton", true);
			oView.getModel("viewModel").setProperty("/Departed", false);
			oView.getModel("viewModel").setProperty("/Pass", false);
			oView.getModel("viewModel").setProperty("/Fail", false);
			oView.getModel("viewModel").setProperty("/Cancel", false);
			oView.getModel("viewModel").setProperty("/Reset", true);
			oUser = new sap.ushell.services.UserInfo().getId();
			this.oModel = this.getView().getModel();
			/*sPath = this.oModel.createKey("/Authorizations", {
				UserName: oUser
			});*/
		},
		handleIconTabBarSelect: function (oEvent) {
			var sKey = oEvent.getParameter("selectedKey");
			switch (sKey) {
			case "Arrival":
				this.getView().getModel("viewModel").setProperty("/ArrivalButton", true);
				this.getView().getModel("viewModel").setProperty("/Departed", false);
				this.getView().getModel("viewModel").setProperty("/Pass", false);
				this.getView().getModel("viewModel").setProperty("/Fail", false);
				this.getView().getModel("viewModel").setProperty("/Cancel", false);
				this.getView().getModel("viewModel").setProperty("/Reset", true);
				break;
			case "Welcome":
				this.getView().getModel("viewModel").setProperty("/ArrivalButton", false);
				this.getView().getModel("viewModel").setProperty("/Departed", false);
				this.getView().getModel("viewModel").setProperty("/Pass", true);
				this.getView().getModel("viewModel").setProperty("/Fail", true);
				this.getView().getModel("viewModel").setProperty("/Cancel", false);
				this.getView().getModel("viewModel").setProperty("/Reset", false);
				break;
			case "Parking":
				this.getView().getModel("viewModel").setProperty("/ArrivalButton", false);
				this.getView().getModel("viewModel").setProperty("/Departed", true);
				this.getView().getModel("viewModel").setProperty("/Pass", false);
				this.getView().getModel("viewModel").setProperty("/Fail", false);
				this.getView().getModel("viewModel").setProperty("/Cancel", false);
				this.getView().getModel("viewModel").setProperty("/Reset", false);
				break;
			}
		},

		onCreate: function () {
			this.TruckArrivalController._onCreate();
		},
		onPressDeparted: function () {
			this.TruckParkingController._onPressDeparted();
		},
		onPass: function () {
			this.TruckWelcomeController._onAccept();
		},
		onFail: function () {
			this.TruckWelcomeController._onReject();
		},
		onCancel: function () {
			this.TruckWelcomeController._onCancel();
		},
		onReset: function () {
			this.TruckArrivalController._onReset();
		}
	});
});