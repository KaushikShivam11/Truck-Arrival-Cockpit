sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/model/formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller, Filter, FilterOperator, JSONModel, formatter, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.controller.Welcome", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		formatter: formatter,

		onInit: function () {
			this.oModel = this.getView().getModel();
			var oArrivalWelcomeModel = new JSONModel();
			this.getView().setModel(oArrivalWelcomeModel, "arrivalWelcomeModel");
			this.getView().byId("idDateValue").setDateValue(new Date());
		},

		onSearch: function () {
			var oTruckLocalModel, oTruckFilter, oDateFilter, sTruckValue, oDate, oAllFilters, oStatusFilter,
				aFilterAll = [];
			this.sSelectedStatus = this.getView().byId("idStatusValue").getSelectedKey();
			sTruckValue = this.getView().byId("idTruckValue").getValue();
			oDate = ((this.getView().byId("idDateValue").getDateValue() === null) ? new Date() : this.formatter.getFormatedDate(this.getView()
				.byId("idDateValue").getDateValue()));
			oTruckFilter = new Filter("TruckNumber", FilterOperator.Contains, sTruckValue);
			oDateFilter = new Filter("CreatedOn", FilterOperator.EQ, oDate);
			oStatusFilter = new Filter("TruckStatus", FilterOperator.EQ, this.sSelectedStatus);
			aFilterAll.push(oDateFilter, oStatusFilter);
			if (sTruckValue !== "") {
				aFilterAll.push(oTruckFilter);
			}
			oAllFilters = new Filter({
				filters: aFilterAll,
				and: true
			});
			this.oModel.read("/ZOGS_TAC_TRUCK_LST", {
				filters: [oAllFilters],
				success: function (oData) {
					oData.results.forEach(function (oTruckItem) {
						oTruckItem.salesOrders = [];
					});
					oTruckLocalModel = new JSONModel(oData.results);
					this.getView().setModel(oTruckLocalModel, "truckLocalModel");
				}.bind(this)
			});
		},

		onStatusChange: function (oEvent) {
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			if (sSelectedKey === "04") {
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					3].setVisible(false);
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					4].setVisible(false);
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					5].setVisible(true);
			} else {
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					3].setVisible(true);
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					4].setVisible(true);
				oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getParent().getFooter().getContent()[
					5].setVisible(false);
			}
		},

		_initializeNewEntry: function () {
			var formData = {
				"IsCreatingFromHO": false,
				"ArrivalDate": null,
				"TruckNumber": "",
				"Plant": "",
				"CreatedBy": "",
				"PlantTxt": "",
				"CallingFrom": "ARRIVAL",
				"oArrivalTime": null,
				"ArrivalTime": null,
				"ReportedBy": ""
			};
			this.getView().getModel("arrivalWelcomeModel").setData(formData);
		},

		onSalesF4: function (oEvent) {
			this.oSalesSource = oEvent.getSource();
			this.GUID = oEvent.getSource().getParent().getBindingContext("truckLocalModel").getObject().GUID;
			this.Truck = oEvent.getSource().getParent().getBindingContext("truckLocalModel").getObject().TruckNumber;
			var aTokensSrv = [],
				aTokens = [],
				sPath;
			this.oSalesSource.getTokens().forEach(function (oToken, iToken) {
				aTokens[iToken] = {
					GUID: oToken.getKey(),
					SalesOrderNo: oToken.getText(),
					ParentGUID: this.GUID
				};
				if (aTokens[iToken].GUID === "") {
					delete aTokens[iToken].GUID;
				}
			}.bind(this));
			sPath = oEvent.getSource().getParent().getBindingContext("truckLocalModel").getPath();
			this.getView().getModel().read("/ZOGS_TAC_TRUCK_LST(guid'" + this.GUID + "')/to_items", {
				success: function (oData) {
					oData.results.forEach(function (oTokenSrv, iTokenSrv) {
						aTokensSrv[iTokenSrv] = {
							GUID: oTokenSrv.guid,
							SalesOrderNo: oTokenSrv.sales_order_no,
							ParentGUID: oTokenSrv.parent_guid
						};
					}.bind(this));
					this.getView().getModel("truckLocalModel").setProperty("/salesOrders", this.formatter.merge_array(aTokens, aTokensSrv));
					if (!this.oSalesDialog) {
						this.oSalesDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.SalesOrderWelcome", this);
						this.getView().addDependent(this.oSalesDialog);
					}
					this.oSalesDialog.open();
				}.bind(this),
				error: function () {
					if (!this.oSalesDialog) {
						this.oSalesDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.SalesOrderWelcome", this);
						this.getView().addDependent(this.oSalesDialog);
					}
					this.oSalesDialog.open();
				}
			});
		},

		onAddOrder: function () {
			var oAddTemplate = {
				ParentGUID: this.GUID,
				SalesOrderNo: "",
				TruckNumber: this.Truck
			};
			var aSalesOrder = this.getView().getModel("truckLocalModel").getProperty("/salesOrders");
			aSalesOrder.push(oAddTemplate);
			this.getView().getModel("truckLocalModel").setProperty("/salesOrders", aSalesOrder);
		},

		onValidate: function () {
			var oTokenTemplate, sPath = this.oSalesSource.getBindingContext("truckLocalModel").getPath(),
				aAddItems = [],
				oPayload = {
					CallingFrom: "WELCOME",
					IsCreatingFromHO: false,
				};
			oPayload.Trucks = [{
				"GUID": this.GUID,
				TruckNumber: this.Truck
			}];
			oPayload.SaleOrders = this.getView().getModel("truckLocalModel").getProperty("/salesOrders");
			if (oPayload.SaleOrders.length === 0 || this.sSelectedStatus === "04") {
				this.getView().getModel("truckLocalModel").setProperty(sPath + "/salesItems", []);
				this.oSalesDialog.close();
			} else {
				this.getView().getModel().create("/Heads", oPayload, {
					success: function (oData, oResponse) {
						/*var sMsg = JSON.parse(oResponse.headers["sap-message"]).message,
							aMsgs = [];
						aMsgs = JSON.parse(oResponse.headers["sap-message"]).details;
						aMsgs.forEach(function (oItem, iIndex) {
							sMsg = sMsg + oItem.message;
						});*/
						oPayload.SaleOrders.forEach(function (oAddItem, iAddIndex) {
							aAddItems[iAddIndex] = {
								GUID: oAddItem.GUID,
								SalesItemNo: oAddItem.SalesOrderNo,
								ParentGUID: oAddItem.ParentGUID
							};
						});
						this.getView().getModel("truckLocalModel").setProperty(sPath + "/salesItems", aAddItems);
						this.oSalesDialog.close();
						//MessageBox.success(sMsg);
					}.bind(this),
					error: function (oError) {
						this.oSalesDialog.close();
						var err = "",
							aErr = [];
						aErr = JSON.parse(oError.responseText).error.innererror.errordetails;
						if (aErr !== undefined) {
							aErr.forEach(function (item, index, arr) {
								if (index === (arr.length - 1)) {
									return;
								}
								err = err + '\n' + item.message;
							});
							MessageBox.error(err);
						} else {
							err = JSON.parse(oError.responseText).error.message.value;
							MessageBox.error(err);
						}
					}.bind(this)
				});
			}
		},

		onPressDelete: function (oEvent) {
			var sPath = oEvent.getParameter("listItem").getBindingContext("truckLocalModel").getPath();
			var aIndex = sPath.split("/");
			var aSalesOrder = this.getView().getModel("truckLocalModel").getProperty("/salesOrders");
			var oToken = aSalesOrder[aIndex[aIndex.length - 1]];
			if (oToken.GUID === "" || oToken.GUID === undefined) {
				aSalesOrder.splice(aIndex[aIndex.length - 1], 1);
				this.getView().getModel("truckLocalModel").setProperty("/salesOrders", aSalesOrder);
			} else {
				this.getView().getModel().remove("/SaleOrders(guid'" + oToken.GUID + "')", {
					success: function () {
						aSalesOrder.splice(aIndex[aIndex.length - 1], 1);
						this.getView().getModel("truckLocalModel").setProperty("/salesOrders", aSalesOrder);
					}.bind(this),
					error: function (oError) {
						var err = "",
							aErr = [];
						aErr = JSON.parse(oError.responseText).error.errordetails;
						if (aErr !== undefined) {
							aErr.forEach(function (item, index) {
								err = err + '\n' + item.message;
							});
							MessageBox.error(err);
						} else {
							err = JSON.parse(oError.responseText).error.message.value;
							MessageBox.error(err);
						}
					}.bind(this)
				});
			}

		},

		onClose: function () {
			this.oSalesDialog.close();
		},

		onSalesArrivalF4: function (oEvent) {
			var aArrivalSalesOrder = [],
				aTokens;
			this.oSalesArrivalInput = oEvent.getSource();
			aTokens = this.oSalesArrivalInput.getTokens();

			if (aTokens.length > 0) {
				aTokens.forEach(function (oItem, iIndex) {
					aArrivalSalesOrder[iIndex] = {
						ArrivalSalesOrder: oItem.getText()
					};
				}.bind(this));
			}
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalSalesOrders", aArrivalSalesOrder);
			if (!this.oDialogNewSales) {
				this.oDialogNewSales = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.SalesArrival", this);
				this.getView().addDependent(this.oDialogNewSales);
			}
			this.oDialogNewSales.open();
		},

		onAddArrivalOrder: function () {
			var oAddTemplate = {
				ArrivalSalesOrder: ""
			};
			var aSalesOrder = this.getView().getModel("arrivalWelcomeModel").getProperty("/ArrivalSalesOrders");
			aSalesOrder.push(oAddTemplate);
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalSalesOrders", aSalesOrder);
		},

		onSetTokens: function () {
			var aSalesTokens = [],
				aAddedTokens = this.getView().getModel("arrivalWelcomeModel").getProperty("/ArrivalSalesOrders");
			aAddedTokens.forEach(function (oSalesToken, iSalesToken) {
				aSalesTokens[iSalesToken] = {
					SalesOrderNo: oSalesToken.ArrivalSalesOrder
				};
			}.bind(this));
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalSalesTokens", aSalesTokens);
			this.oDialogNewSales.close();
		},

		onCloseSalesNew: function () {
			this.oDialogNewSales.close();
		},

		onDeleteToken: function (oEvent) {
			var sPath = oEvent.getParameter("listItem").getBindingContext("arrivalWelcomeModel").getPath();
			var aIndex = sPath.split("/");
			var aSalesOrder = this.getView().getModel("arrivalWelcomeModel").getProperty("/ArrivalSalesOrders");
			aSalesOrder.splice(aIndex[aIndex.length - 1], 1);
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalSalesOrders", aSalesOrder);
		},

		onCreateNewTruck: function () {
			this.getView().getModel().read("/ZOGS_TAC_PLANT_LST", {
				success: function (oData) {
					this.getView().getModel("arrivalWelcomeModel").setProperty("/PlantTxt", oData.results[0].PlantTxt);
					this.getView().getModel("arrivalWelcomeModel").setProperty("/Plant", oData.results[0].Plant);
				}.bind(this),
				error: function () {

				}
			});
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.ArrivalWelcome", this);
				this.getView().addDependent(this.oDialog);
			}
			sap.ui.getCore().byId("Fragdatepic").setDateValue(new Date());
			sap.ui.getCore().byId("FragTimepic").setDateValue(this.formatter.getTimeOnly());
			jQuery.sap.delayedCall(500, this, this.oDialog.open());

		},
		onCloseDialog: function () {
			this.oDialog.close();
		},

		onTruckF4: function () {
			this.getView().setBusy(true);
			this.getView().getModel().read("/ZOGS_TAC_VEHICLE_LST", {
				success: function (oData) {
					this.getView().getModel("arrivalWelcomeModel").setProperty("/TruckResults", oData.results);
					this.getView().setBusy(false);
					this.oTruckDialog.setBusy(false);
				}.bind(this)
			});
			if (!this.oTruckDialog) {
				this.oTruckDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.TruckWelcome", this);
				this.getView().addDependent(this.oTruckDialog);
			}
			this.oTruckDialog.setBusy(true);
			this.oTruckDialog.open();
		},

		handleTruckSearch: function (oEvent) {
			var oBinding, oFilterVehicleNo, oFilterType, oFilterCarrier, oFilterAll, sValue = oEvent.getParameter("value");
			oFilterVehicleNo = new Filter("VehicleNumber", FilterOperator.EQ, sValue);
			oFilterType = new Filter("VehicleType", FilterOperator.Contains, sValue);
			oFilterCarrier = new Filter("CarrierID", FilterOperator.EQ, sValue);
			oFilterAll = new Filter({
				filters: [oFilterVehicleNo, oFilterType, oFilterCarrier],
				and: false
			});
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterAll]);
		},

		handleTruckConfirm: function (oEvent) {
			var oBinding, oBindingContext = oEvent.getParameter("selectedItem").getBindingContext("arrivalWelcomeModel").getObject();
			this.getView().getModel("arrivalWelcomeModel").setProperty("/TruckNumber", oBindingContext.VehicleNumber);
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		handleTruckClose: function (oEvent) {
			var oBinding;
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		onDriverF4: function (oEvent) {
			this.getView().setBusy(true);
			this.getView().getModel().read("/ZOGS_TAC_DRIVER_LST", {
				success: function (oData) {
					this.getView().getModel("arrivalWelcomeModel").setProperty("/results", oData.results);
					this.getView().setBusy(false);
					this.oDriverDialog.setBusy(false);
				}.bind(this)
			});
			if (!this.oDriverDialog) {
				this.oDriverDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.DriverWelcome", this);
				this.getView().addDependent(this.oDriverDialog);
			}
			this.oDriverDialog.open();
			this.oDriverDialog.setBusy(true);
		},

		handleDriverSearch: function (oEvent) {
			var oBinding, oFilterCode, oFilterName, oFilterCarrier, oFilterAll, sValue = oEvent.getParameter("value");
			oFilterCode = new Filter("DriverCode", FilterOperator.EQ, sValue);
			oFilterName = new Filter("FullName", FilterOperator.Contains, sValue);
			oFilterCarrier = new Filter("CarrierID", FilterOperator.EQ, sValue);
			oFilterAll = new Filter({
				filters: [oFilterCode, oFilterName, oFilterCarrier],
				and: false
			});
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilterAll]);
		},

		handleConfirm: function (oEvent) {
			var oBindingContext = oEvent.getParameter("selectedItem").getBindingContext("arrivalWelcomeModel").getObject();
			this.getView().getModel("arrivalWelcomeModel").setProperty("/DriverCode", oBindingContext.DriverCode);
			this.getView().getModel("arrivalWelcomeModel").setProperty("/FullName", oBindingContext.FullName);
		},

		handleClose: function (oEvent) {
			var oBinding;
			oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([]);
		},

		onCreate: function () {
			this.getView().setBusy(true);
			var oPayload = {},
				oDate = this.formatter.getFormatedDate(this.getView().getModel("arrivalWelcomeModel").getProperty("/ArrivalDate")),
				sTime;
			sTime = this.formatter.getFormatedTime(this.getView().getModel("arrivalWelcomeModel").getProperty("/oArrivalTime"));
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalDate", oDate);
			this.getView().getModel("arrivalWelcomeModel").setProperty("/ArrivalTime", sTime);
			oPayload.CallingFrom = "WELCOME";
			oPayload.IsCreatingFromHO = true;
			oPayload.Trucks = [];
			oPayload.SaleOrders = this.getView().getModel("arrivalWelcomeModel").getProperty("/ArrivalSalesTokens");
			if (oPayload.SaleOrders === undefined || oPayload.SaleOrders.length === 0){
				MessageBox.error("Please Add Sales Order");
				return;
			}
			oPayload.Trucks.push(this.getView().getModel("arrivalWelcomeModel").getData());
			delete oPayload.Trucks[0].results;
			delete oPayload.Trucks[0].TruckResults;
			delete oPayload.Trucks[0].FullName;
			delete oPayload.Trucks[0].oArrivalTime;
			delete oPayload.Trucks[0].ArrivalSalesTokens;
			delete oPayload.Trucks[0].ArrivalSalesOrders;
			this.oModel.create("/Heads", oPayload, {
				success: function (oData, oResponse) {
					MessageBox.show("Truck Details Created");
					this._initializeNewEntry();
					this.getView().setBusy(false);
					this.oDialog.close();
				}.bind(this),
				error: function (oError) {
					var err = "",
						aErr = [];
					aErr = JSON.parse(oError.responseText).error.errordetails;
					if (aErr !== undefined) {
						aErr.forEcah(function (item, index) {
							err = err + '\n' + item.message;
						});
						MessageBox.error(err);
					} else {
						err = JSON.parse(oError.responseText).error.message.value;
						MessageBox.error(err);
					}
					this.getView().setBusy(false);
					this._initializeNewEntry();
					this.oDialog.close();
				}.bind(this)
			});
		},

		_onAccept: function () {
			this._createPayLoad("PASS");
		},

		_onReject: function () {
			this._createPayLoad("FAIL");
		},

		_onCancel: function () {
			this._createPayLoad("CANCEL");
		},

		_createPayLoad: function (sAction) {
			this.getView().setBusy(true);
			var aTokens = [],
				aTokenObject = [],
				oPayLoad = {
					"Trucks": [],
					"SaleOrders": []
				},
				sPath, aSelectedItems = this.getView().byId("welcomeTable").getSelectedItems();
			if (aSelectedItems.length === 0) {
				MessageToast.show("Select Atleast one Truck");
				this.getView().setBusy(false);
				return;
			} else {
				aSelectedItems.some(function (oItem, iIndex) {
					aTokenObject = [];
					sPath = oItem.getBindingContext("truckLocalModel").getPath();
					oPayLoad.Trucks[iIndex] = {
						GUID: this.getView().getModel("truckLocalModel").getProperty(sPath).GUID,
						TruckNumber: this.getView().getModel("truckLocalModel").getProperty(sPath).TruckNumber
					};
					aTokens = this.getView().getModel("truckLocalModel").getProperty(sPath + "/salesItems");
					if ((aTokens === undefined || aTokens.length === 0) && this.sSelectedStatus !== "04") {
						MessageBox.error("Select Sales Order for Truck Number " +
							this.getView().getModel("truckLocalModel").getProperty(sPath).TruckNumber);
						this.getView().setBusy(false);
						return true;
					}
					if ((aTokens === undefined || aTokens.length === 0) && this.sSelectedStatus === "04") {
						aTokens = [];
					}
					aTokens.forEach(function (oToken, iToken, aToken) {
						aTokenObject[iToken] = {
							GUID: oToken.GUID,
							ParentGUID: oToken.ParentGUID,
							SalesOrderNo: oToken.SalesItemNo,
							TruckNumber: this.getView().getModel("truckLocalModel").getProperty(sPath).TruckNumber
						};
						if (aTokenObject[iToken].GUID === undefined) {
							delete aTokenObject[iToken].GUID;
						}
					}.bind(this));
					oPayLoad.SaleOrders = oPayLoad.SaleOrders.concat(aTokenObject);
					if (iIndex === aSelectedItems.length - 1) {
						oPayLoad.ActionTaken = sAction;
						oPayLoad.CallingFrom = "WELCOME";
						oPayLoad.IsCreatingFromHO = false;
						this.getView().getModel().create("/Heads", oPayLoad, {
							success: function (oData, oResponse) {
								this.getView().setBusy(false);
								aSelectedItems.forEach(function (oSelectedItem) {
									var sItemPath = oSelectedItem.getBindingContext("truckLocalModel").getPath();
									this.getView().getModel("truckLocalModel").setProperty(sItemPath + "/salesItems", []);
								}.bind(this));
								this.getView().getModel("truckLocalModel").setProperty("/salesOrders", []);
								var sMsg = JSON.parse(oResponse.headers["sap-message"]).message,
									aMsgs = [];
								aMsgs = JSON.parse(oResponse.headers["sap-message"]).details;
								aMsgs.forEach(function (oItem, iIndex) {
									sMsg = sMsg + "\n" + oItem.message;
								});
								MessageBox.success(sMsg);
								this.onSearch();
							}.bind(this),
							error: function (oError) {
								this.getView().setBusy(false);
								var err = "",
									aErr = [];
								aErr = JSON.parse(oError.responseText).error.innererror.errordetails;
								if (aErr !== undefined) {
									aErr.forEach(function (item, index, arr) {
										if (index === (arr.length - 1)) {
											return;
										}
										err = err + '\n' + item.message;
									});
									MessageBox.error(err);
								} else {
									err = JSON.parse(oError.responseText).error.message.value;
									MessageBox.error(err);
								}
							}.bind(this)
						});
					}
				}.bind(this));
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onExit: function() {
		//
		//	}

	});

});