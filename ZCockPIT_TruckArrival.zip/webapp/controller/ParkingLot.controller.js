sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/model/formatter",
	"sap/m/Token",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, Filter, FilterOperator, JSONModel, formatter, Token, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.controller.ParkingLot", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		formatter: formatter,

		onInit: function () {
			this.oModel = this.getView().getModel();
			this.getView().byId("idOrderValue").setDateValue(new Date());
		},

		onSearch: function () {
			var oParkingLocalModel, oTruckFilter, oDateFilter, sTruckValue, oDate, oAllFilters, oStatusFilter,
				aFilterAll = [];
			sTruckValue = this.getView().byId("idTruckValue").getValue();
			oDate = ((this.getView().byId("idOrderValue").getDateValue() === null) ? new Date() : this.formatter.getFormatedDate(this.getView()
				.byId("idOrderValue").getDateValue()));
			oTruckFilter = new Filter("TruckNumber", FilterOperator.Contains, sTruckValue);
			oDateFilter = new Filter("CreatedOn", FilterOperator.EQ, oDate);
			oStatusFilter = new Filter("TruckStatus", FilterOperator.EQ, "01");
			aFilterAll.push(oDateFilter, oStatusFilter);
			if (sTruckValue !== "") {
				aFilterAll.push(oTruckFilter);
			}
			oAllFilters = new Filter({
				filters: aFilterAll,
				and: true
			});
			this.oModel.read("/ZOGS_TAC_TRUCK_LST", {
				filters: [oAllFilters],
				success: function (oData) {
					oParkingLocalModel = new JSONModel(oData.results);
					oData.results.forEach(function (oTruckItem) {
						oTruckItem.salesOrders = [];
					});
					this.getView().setModel(oParkingLocalModel, "parkingLocalModel");
				}.bind(this)
			});
			//this.oSourceInput.setTokens([]);
		},

		onSalesF4: function (oEvent) {
			var aSalesOrder = [],
				aTokensSrv = [],
				aTokens, sPath, oSalesFilter;
			this.oSourceInput = oEvent.getSource();
			this.GUID = oEvent.getSource().getParent().getBindingContext("parkingLocalModel").getObject().GUID;
			this.Truck = oEvent.getSource().getParent().getBindingContext("parkingLocalModel").getObject().TruckNumber;;
			sPath = oEvent.getSource().getParent().getBindingContext("parkingLocalModel").getPath();
			aTokens = this.oSourceInput.getTokens();

			if (aTokens.length > 0) {
				aTokens.forEach(function (oItem, iIndex) {
					aSalesOrder[iIndex] = {
						GUID: this.GUID,
						SalesOrderNo: oItem.getText()
					};
				}.bind(this));
			}
			oSalesFilter = new Filter("GUID", FilterOperator.EQ, this.GUID);
			this.getView().getModel().read("/SaleOrders", {
				filters: [oSalesFilter],
				success: function (oData) {
					oData.results.forEach(function (oTokenSrv, iTokenSrv) {
						aTokensSrv[iTokenSrv] = {
							GUID: this.GUID,
							SalesOrderNo: oTokenSrv.sales_order_no
						};
					}.bind(this));
					this.getView().getModel("parkingLocalModel").setProperty("/salesOrders", this.formatter.merge_array(aSalesOrder, aTokensSrv));
					if (!this.oSalesDialog) {
						this.oSalesDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.SalesOrder", this);
						this.getView().addDependent(this.oSalesDialog);
					}
					this.oSalesDialog.open();
				}.bind(this),
				error: function () {
					if (!this.oSalesDialog) {
						this.oSalesDialog = sap.ui.xmlfragment("ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.fragments.SalesOrder", this);
						this.getView().addDependent(this.oSalesDialog);
					}
					this.oSalesDialog.open();
				}.bind(this)
			});
		},

		onAddOrder: function () {
			var oAddTemplate = {
				GUID: this.GUID,
				SalesOrderNo: "",
				TruckNumber: this.Truck
			};
			var aSalesOrder = this.getView().getModel("parkingLocalModel").getProperty("/salesOrders");
			aSalesOrder.push(oAddTemplate);
			this.getView().getModel("parkingLocalModel").setProperty("/salesOrders", aSalesOrder);
		},

		onPressDelete: function (oEvent) {
			var sPath = oEvent.getParameter("listItem").getBindingContext("parkingLocalModel").getPath();
			var aIndex = sPath.split("/");
			var aSalesOrder = this.getView().getModel("parkingLocalModel").getProperty("/salesOrders");
			aSalesOrder.splice(aIndex[aIndex.length - 1], 1);
			this.getView().getModel("parkingLocalModel").setProperty("/salesOrders", aSalesOrder);
		},

		onValidate: function (oEvent) {
			var sPath = this.oSourceInput.getBindingContext("parkingLocalModel").getPath(),
				aAddItems = [],
				oPayload = {
					CallingFrom: "CALL",
					IsCreatingFromHO: false
				};
			oPayload.Trucks = [{
				"GUID": this.GUID,
				"TruckNumber": this.Truck
			}];
			oPayload.SaleOrders = this.getView().getModel("parkingLocalModel").getProperty("/salesOrders");
			if (oPayload.SaleOrders.length === 0) {
				this.getView().getModel("parkingLocalModel").setProperty(sPath + "/salesItems", []);
				this.oSalesDialog.close();
			} else {
				this.getView().getModel().create("/Heads", oPayload, {
					success: function (oData, oResponse) {
						oPayload.SaleOrders.forEach(function (oAddItem, iAddIndex) {
							aAddItems[iAddIndex] = {
								GUID: oAddItem.GUID,
								SalesItemNo: oAddItem.SalesOrderNo
							};
						});
						this.getView().getModel("parkingLocalModel").setProperty(sPath + "/salesItems", aAddItems);
						this.oSalesDialog.close();
					}.bind(this),
					error: function (oError) {
						this.oSalesDialog.close();
						var err = JSON.parse(oError.responseText).error.message.value;
						MessageToast.show(err);
					}.bind(this)
				});
			}
		},

		onClose: function () {
			this.oSalesDialog.close();
		},

		_onPressDeparted: function () {
			this.getView().setBusy(true);
			var aTokens, aTokenObject = [],
				oPayLoad = {
					"Trucks": [],
					"SaleOrders": []
				},
				sPath, aSelectedItems = this.getView().byId("parkingTable").getSelectedItems();
			if (aSelectedItems.length === 0) {
				MessageToast.show("Select Atleast one Truck");
				this.getView().setBusy(false);
				return;
			} else {
				aSelectedItems.forEach(function (oItem, iIndex) {
					aTokenObject = [];
					sPath = oItem.getBindingContext("parkingLocalModel").getPath();
					oPayLoad.Trucks[iIndex] = {
						GUID: this.getView().getModel("parkingLocalModel").getProperty(sPath).GUID,
						TruckNumber: this.getView().getModel("parkingLocalModel").getProperty(sPath).TruckNumber
					};
					aTokens = oItem.getCells()[4].getTokens();
					aTokens.forEach(function (oToken, iToken) {
						aTokenObject[iToken] = {
							GUID: this.getView().getModel("parkingLocalModel").getProperty(sPath).GUID,
							SalesOrderNo: oToken.getText(),
							TruckNumber: this.getView().getModel("parkingLocalModel").getProperty(sPath).TruckNumber
						};
					}.bind(this));
					oPayLoad.SaleOrders = oPayLoad.SaleOrders.concat(aTokenObject);
				}.bind(this));
				oPayLoad.ActionTaken = "DEPARTED";
				oPayLoad.CallingFrom = "CALL";
				oPayLoad.IsCreatingFromHO = false;
				this.getView().getModel().create("/Heads", oPayLoad, {
					success: function () {
						this.getView().setBusy(false);
						aSelectedItems.forEach(function (oSelectedItem) {
							var sItemPath = oSelectedItem.getBindingContext("parkingLocalModel").getPath();
							this.getView().getModel("parkingLocalModel").setProperty(sItemPath + "/salesItems", []);
						}.bind(this));
						this.getView().getModel("parkingLocalModel").setProperty("/salesOrders", []);
						this.onSearch();
					}.bind(this),
					error: function (oError) {
						this.getView().setBusy(false);
						var err = "",
							aErr = [];
						aErr = JSON.parse(oError.responseText).error.innererror.errordetails;
						if (aErr !== undefined) {
							aErr.forEach(function (item, index, arr) {
								if (index === (arr.length - 1)) {
									return;
								}
								err = err + '\n' + item.message;
							});
							MessageBox.error(err);
						} else {
							err = JSON.parse(oError.responseText).error.message.value;
							MessageBox.error(err);
						}
					}.bind(this)
				});
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZCockPIT_TruckArrival.ZCockPIT_TruckArrival.view.ParkingLot
		 */
		//	onExit: function() {
		//
		//	}

	});

});