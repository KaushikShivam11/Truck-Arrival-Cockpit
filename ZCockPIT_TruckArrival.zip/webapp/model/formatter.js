sap.ui.define([], function () {
	return {
		getFormatedTime: function (oTime) {
			if (oTime === null) {
				return;
			} else {
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "PTHH'H'mm'M'ss'S'"
				});
				return oTimeFormat.format(oTime);
			}
		},
		getTimeString: function (sTime) {
			if (sTime === "") {
				return;
			} else {
				var oTimeZoneOffset = new Date().getTimezoneOffset() * 60 * 1000;
				sTime = sTime + oTimeZoneOffset;
				var oTimeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "hh:mm a"
				});
				return oTimeFormat.format(new Date(sTime));
			}
		},

		getTimeOnly: function () {
			var oDate = new Date();
			var sTime = oDate.getTime();
			var mm = oDate.getMonth() + 1;
			var dd = oDate.getDate();
			var sDate = [oDate.getFullYear(), (mm > 9 ? '' : '0') + mm,
				(dd > 9 ? '' : '0') + dd
			].join("-");
			var sTimeZero = new Date(sDate).getTime();
			return new Date(sTime - sTimeZero);
		},

		getFormatedDate: function (oDate) {
			if (oDate === null) {
				return;
			} else {
				var oTimeZoneOffset = oDate.getTimezoneOffset() * 60 * 1000;
				var oFormattedDate = new Date(oDate.getTime() - (oTimeZoneOffset));
				return oFormattedDate;
			}
		},
		getParssedDate: function (oDate) {
			if (oDate === null) {
				return;
			} else {
				var oTimeZoneOffset = oDate.getTimezoneOffset() * 60 * 1000;
				var oFormattedDate = new Date(oDate.getTime() + (oTimeZoneOffset));
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd-MM-yyyy"
				});
				return dateFormat.format(oFormattedDate);
			}
		},

		merge_array: function (array1, array2) {
			var result_array = [];
			var arr = array1.concat(array2);
			var len = arr.length;
			var assoc = {};

			while (len--) {
				var item = arr[len];

				if (!assoc[item.SalesOrderNo]) {
					result_array.unshift(item);
					assoc[item.SalesOrderNo] = true;
				}
			}

			return result_array;
		},
	};
});