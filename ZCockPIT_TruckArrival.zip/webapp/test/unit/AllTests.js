sap.ui.define([
	"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/test/unit/controller/View1.controller"
], function () {
	"use strict";
});