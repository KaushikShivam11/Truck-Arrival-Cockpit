/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});