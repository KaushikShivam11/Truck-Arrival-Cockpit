/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"ZCockPIT_TruckArrival/ZCockPIT_TruckArrival/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});